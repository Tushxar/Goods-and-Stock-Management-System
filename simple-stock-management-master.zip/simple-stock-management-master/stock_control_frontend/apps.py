from django.apps import AppConfig


class StockControlFrontendConfig(AppConfig):
    name = 'stock_control_frontend'
