from django.apps import AppConfig


class StockControlConfig(AppConfig):
    name = 'stock_control'
