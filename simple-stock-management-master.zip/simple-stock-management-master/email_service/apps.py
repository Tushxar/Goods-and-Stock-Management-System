from django.apps import AppConfig


class EmailServiceConfig(AppConfig):
    name = 'email_service'
